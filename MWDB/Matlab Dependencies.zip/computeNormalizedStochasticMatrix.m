function [ stochasticMatrix ] = computeNormalizedStochasticMatrix( adjacencyMatrix )
%Given the adjacency matrix, this function finds the stochastic Matrix
    
    [m,n] = size(adjacencyMatrix);
    stochasticMatrix = zeros(m,n);
    for i = 1:n
        col = adjacencyMatrix(:,i);
        [a,b] = size(col);
        s  = sum(col);
        if (s~=0)
            for j =1:a
              col(j) = col(j)/s;
            end
            stochasticMatrix(:,i)=col;
        end
    end
end

