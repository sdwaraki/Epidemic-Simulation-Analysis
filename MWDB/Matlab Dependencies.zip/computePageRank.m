function [ ] = computePageRank( inputPageRankMatrix )
%Compute the PageRank Matrix given a weighted stochastic adjacency matrix
    
    [m,n] = size(inputPageRankMatrix);
    %threshold = 0.000000000000001;
    rMatrix = zeros(n,1);
    iteration =1;
    %difference =1;
    for i = 1:n
        rMatrix(i) = 1/n;
    end
    rdMatrix = zeros(n,1);
    
    %while (difference > threshold) 
     while(rMatrix~=rdMatrix)
        if(iteration==1)
            rdMatrix = mtimes(inputPageRankMatrix,rMatrix);
        else
            rMatrix = rdMatrix;
            rdMatrix = mtimes(inputPageRankMatrix,rMatrix);
        end
        iteration = iteration+1;
        %difference = computeMaxDifference(rMatrix, rdMatrix);
    end
    
     [B,index]=sort(rdMatrix,1,'descend');
		[rows,cols]=size(rdMatrix);
		for i=1:rows
            fprintf('Document=%d    PageRank=%d \n',index(i),B(i));
        end
%     disp(rdMatrix);
end

