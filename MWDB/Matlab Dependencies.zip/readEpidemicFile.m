function [similarity] = readEpidemicFile(directory,file1,queryPath)

    
    fileMatrix1 = csvread(file1,0,3);
    [m,n]=size(fileMatrix1);
    revisedMatrix1 = zeros;
    
    for i = 1:m
        for j = 1:n-1
            revisedMatrix1(i,j)=fileMatrix1(i,j);
        end
    end
    
    fileMatrix2 = csvread(queryPath,0,3);
    [m,n] = size(fileMatrix2);
    revisedMatrix2 = zeros;
    
    for i = 1:m
        for j = 1:n-1
            revisedMatrix2(i,j)=fileMatrix2(i,j);
        end
    end
    
    for i = 1:m
       row1 = revisedMatrix1(i,:);
       row2 = revisedMatrix2(i,:);
       euc(i,1) = pdist2(row1,row2,'euclidean');
    end
    
    sum =0;
    
    [a,b] = size(euc);
    
    for i = 1:a
        sum = sum+euc(a,1);
    end
    
    avg = sum/a;
    
    similarity = 1/(1+avg);
    
    
    


end
