function [ distanceMatrix ] = GetSimulationSimilarityMatrix( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

dirPath = 'C:/Users/Sumanth/workspace/Phase 1 Programs/InputData/'
n =length(dir([dirPath '\*.csv']));
distanceMatrix=zeros(n,n);



for i=1:n
    disp(i);
    file1path = [dirPath num2str(i) '.csv'];
    file1Matrix = csvread(file1path,2,3); 
    file1Matrix = transpose(file1Matrix);
    for j=1:n
        disp(j);
        file2path = [dirPath num2str(j) '.csv'];
        file2Matrix = csvread(file2path,2,3); 
        file2Matrix = transpose(file2Matrix);
        if(distanceMatrix(i,j)==0)
            distanceMatrix(i,j)= findEucledian(file1Matrix,file2Matrix);
            distanceMatrix(j,i)= distanceMatrix(i,j);   
        end
    end
end


end

