function [similarity] = getDTW(matrix1, matrix2)
    
    %Obtaining sizes of the Matrices
    [m,n] = size(matrix1);
    [p,q] = size(matrix2);
    
    % For each state, compute the DTW distance between one state vector in 
    % one simulation file and the corresponding state in the 2nd simulation
    % file.
    % computeDTW function computes the DTW path and the cost of the
    % distance matrix.
    for i =1:m
       
        row1 = matrix1(i,:);
        row2 = matrix2(i,:);
        
        [row_row1,col_row1] = size(row1);
        [row_row2,col_row2] = size(row2);
        
        for j = 1:col_row1
            k=1;
            for k=1:col_row2
               matrix(j,k) =  (row1(row_row1,j)-row2(row_row2,k))^2;
            end
        end
        
        dtwvalue(i) = computeDtw(matrix);
        
    end
    
    [a,b] = size(dtwvalue);
    
    sum=0;
    
    %  To obtain the Similarity Scores.
    for i = 1:b
        dtwvalue(1,i)= sqrt(dtwvalue(1,i));
        sum = sum+dtwvalue(1,i);
    end
    
    avg = sum/a;
    
    similarity = 1/(1+avg);

end
