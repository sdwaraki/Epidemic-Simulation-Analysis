function [ similarityMatrix ] = computeSimilarityMatrix()
    % Calculates the Eucledian distance between all pairs of simulations
    % and take the inverse of it to get the Similarity Matrix
    
    tempMatrix = GetSimulationSimilarityMatrix();
    [m,n] = size(tempMatrix);
    
    for i =1 : m
        for j=1 : n
                tempMatrix(i,j)=1/(1+tempMatrix(i,j));
        end
    end
    
    similarityMatrix = tempMatrix;

end
