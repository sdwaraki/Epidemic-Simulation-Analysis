function [ ] = testInput( varargin )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
    
    if(nargin==0)
        disp('Nothing was present');
    else
        x = varargin{1};
        disp([num2str(x)]);
    end
   

end

