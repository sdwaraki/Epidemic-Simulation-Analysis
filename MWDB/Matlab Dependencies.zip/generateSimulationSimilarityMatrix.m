function [ similarityMatrix ] = generateSimulationSimilarityMatrix( choice )
%Computes the simulation Similarity Matrix on Eucledian and DTW similarity
%measure based on the choice value

    dirPath = 'C:\Users\Sumanth\Desktop\Fall 2014\MWDB\SampleData_P3_F14\SampleData_P3_F14\Data\';
    similarityMatrix = zeros;
    %Find the count of the number of files in the directory
    n =length(dir([dirPath '\*.csv']));
    %x = dir(strcat(dirPath,'*.csv'));
    %Computing the Simulation Similarity Matrix
    for i = 1:n
        disp(i);
        for j= i+1:n
            if choice==1
                similarityMatrix(i,j) = Phase2_Task1a(i,j);
                similarityMatrix(j,i) = similarityMatrix(i,j);
            else
                similarityMatrix(i,j) = Phase2_Task1b(i,j);
                similarityMatrix(j,i) = similarityMatrix(i,j);
            end    
        end    
    end

    %Computing the diagonal Values of the Simulation Similarity Matrix
    for i =1:n
        similarityMatrix(i,i)=1;
    end
end

