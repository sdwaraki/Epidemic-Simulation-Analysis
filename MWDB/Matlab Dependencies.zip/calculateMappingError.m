function mappingError= calculateMappingError(k,pivot,col)

%Computes the n by n distance matrix 
dist = GetSimulationSimilarityMatrix();

[row_dist,col_dist]= size(dist);
n=row_dist;
x=zeros(n,k);

new_dist = dist;

%Map all the objects in latent dimensional space 
new_x =fastmap2(k,dist,pivot,x,col,n);

[m,nx]=size(new_x);
A=zeros(1,nx); 
B=zeros(1,nx);
newDistMatrix=zeros(m,m);
distSum=0;
newDistSum=0;

%Calculating the object by object matrix in the latent dimensional space
  for i =1:m
      A(1,:)=new_x(i,:);          
     
      for j=i+1:m
          
        B(1,:)=new_x(j,:);
        newDistMatrix(i,j)=norm(A-B);
        newDistMatrix(j,i)=newDistMatrix(i,j);
        
      end  
        
          
  end  
  
%sum up the new distmatrix and original dist matrix  
[k,l]=size(new_dist);
for i=1:k
    for j=1:l
        distSum=distSum+new_dist(i,j);
        newDistSum=newDistSum+newDistMatrix(i,j);
        
    end
end



%calculates the mapping error
mappingError=abs(newDistSum-distSum);


end
          
          