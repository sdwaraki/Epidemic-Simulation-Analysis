function [] = makeHeatMap(inputMatrix, maxWindowStart, maxStateNumber, minWindowStart, minStateNumber, windowSize, maxOneHopNeighbors, minOneHopNeighbors)
    m = transpose(inputMatrix);
    colormap('hot');
    imagesc(m);
    colorbar;
    hold on;
    [m,n] = size(maxOneHopNeighbors);
    [x,y] = size(minOneHopNeighbors);
    s = rectangle('Position',[maxWindowStart,maxStateNumber,windowSize,1]);
    set(s,'edgecolor','b');
    hold on;
    for i=1:n
        %hold;
        %plot(maxWindowStart,maxOneHopNeighbors(1,i),'x','MarkerSize',5);
        if n~=1 && maxOneHopNeighbors(1,1) ~= -1 
            l = rectangle('Position',[maxWindowStart,maxOneHopNeighbors(1,i),windowSize,1]);
            set(l,'edgecolor','m');
        end
    end
    hold on;
    t = rectangle('Position',[minWindowStart,minStateNumber,windowSize,1]);
    set(t,'edgecolor','w');
    hold on;
       for i=1:y
            %hold;
           %plot(minWindowStart,minOneHopNeighbors(1,i),'o','MarkerSize',5);
           if y~=1 && minOneHopNeighbors(1,1) ~= -1 
             k = rectangle('Position',[minWindowStart, minOneHopNeighbors(1,i),windowSize,1]); 
             set(k,'edgecolor','g');
           end
       end
end
    