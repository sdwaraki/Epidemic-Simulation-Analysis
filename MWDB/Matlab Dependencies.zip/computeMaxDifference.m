function [ maxDifference ] = computeMaxDifference( rMatrix, rdMatrix )
% This function captures the maximum difference of element by element
% comparison between the two vectors.

    maxDifference = abs(rMatrix(1) - rdMatrix(1));

    [m,n] = size(rMatrix);

    for i = 2:m
        diff = abs(rMatrix(i)-rdMatrix(i));
        if(diff>maxDifference)
            maxDifference = diff;
        end
    end
    
end

