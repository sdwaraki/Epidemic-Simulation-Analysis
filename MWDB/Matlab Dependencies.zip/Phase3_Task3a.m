function [adjacencyMatrix] = Phase3_Task3a(choice,varargin)
% Phase3_Task3a -> Builds weighted epidemic simulation similarity graph, where there is an edge
%between two simulations if their similarity is beyond a given threshold ?.

%Uses the follows files/tools:
%   1. generateSimulationSimilarityMatrix.m      : Gets the Simulation
%   similarity Matrix using Eucledian distance measure or DTW distance
%   measure based on the choice.
%  
%   2. getAdjacencyMatrixWithThreshold.m    : Computes the Adjacency Matrix
%   using the similarityMatrix and the threshold.
%   
%   3. generateAdjacencyMatrix
    [a,b] = size(varargin);
    
    if(b==0)    
        similarityMatrix = generateSimulationSimilarityMatrix(choice);
        adjacencyMatrix = generateAdjacencyMatrix(similarityMatrix);
        openvar('adjacencyMatrix');
    else
        similarityMatrix = varargin{1};
        [m,n] = size(similarityMatrix);
        for i = 1:n
            row = similarityMatrix(i,:);
            maximum = max(row(:));
            [r,c] = size(row);
            for j =1:c
                row(j) = row(j)/maximum;
            end
            similarityMatrix(i,:) = row;
        end    
        adjacencyMatrix = generateAdjacencyMatrix(similarityMatrix);
        %disp(adjacencyMatrix);
        openvar('adjacencyMatrix');
    end
    prompt = [' Do you want to continue with the Task??, Select Choice------- 1) Task 3b    2) Task 3c  3) Exit       Enter 1/2/3:  '];
    inputChoice = input(prompt);
    if(inputChoice==1)
        %Phase3_Task3b(adjacencyMatrix);
        Alternate_Phase3_Task3b(adjacencyMatrix);
    elseif (inputChoice==2)
       % Phase3_Task3c(adjacencyMatrix);
       Alternate_Phase3_Task3c(adjacencyMatrix);
    else
        exit(0);
    end
    
 end

