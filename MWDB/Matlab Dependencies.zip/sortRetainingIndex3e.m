function [ ] = sortRetainingIndex3e( D )
        D=transpose(D);
        [B,index]=sort(D,1,'descend');
		[rows,cols]=size(D);
		for i=1:cols
            for j=1:rows
                fprintf('Document=%d and Score=%d \n',full(index(j,i)),full(B(j,i)))
            end
		end
    
end

