function [kobjectindex]=findSimilarSimulations(k,r,queryFilePath)
    
    dist = GetSimulationSimilarityMatrix();
    queryVector = queryInFileSpace(queryFilePath);
    %distance vector
    [p,q]=size(dist);
    %p=p+1;
   % q=q+1;
    newDistMatrix=zeros(p+1,q+1);
    kobjects=zeros(1,k);
%     distQueryVector=calculateDistanceMatrix(queryVector);
     distQueryVector=queryVector;
   % newDistMatrix=dist;
     for i=1:p
        for j=1:q
            
           newDistMatrix(i,j)=dist(i,j);
           newDistMatrix(j,i)=newDistMatrix(i,j);
        end
     end
    [e,t]=size(newDistMatrix); 
    %append to the last row and last column of dist matrix
                
            
            newDistMatrix(e,:)=distQueryVector(1,:);
            newDistMatrix(:,t)=transpose(distQueryVector(1,:));
              
    
    %call fastmap
    [m,n]=size(newDistMatrix);
    xmatrix=zeros(n,r);
    col=0;
    pivot=zeros(2,r);
    xmatrix=fastmap2(r,newDistMatrix,pivot,xmatrix,col,n);
    
    [v,q]=size(xmatrix);

    J=zeros(1,q); 
    K=zeros(1,q);
    finalVector=zeros(1,v-1);

      for i =v:v
          J(1,:)=xmatrix(i,:);          

          for j=1:v-1
            
            K(1,:)=xmatrix(j,:);
            finalVector(1,j)=norm(J-K);

          end  


      end  
      
     
     %sort the last row  which is the query vector
    sortedDistanceVector= sort(finalVector);
    [g,h]=size(sortedDistanceVector);
    for i=1:k 
        kobjects(1,i)=sortedDistanceVector(1,i);
    end
    
    kobjectindex=zeros(1,k);
    for i=1:k
        for j=1:h
            if kobjects(1,i)==finalVector(1,j)
                kobjectindex(1,i)=j;
                continue;
            end    
                
        end
    end
    

end


%compute similarity measure between this and other simulation file
%In other words ,distance matrix

