function [ ] = Alternate_Phase3_Task3b( adjacencyMatrix )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
    stochasticMatrix = computeNormalizedStochasticMatrix(adjacencyMatrix);
    
    [m,n] = size(stochasticMatrix);
    
    %Generate the reset vector
    resetVector = zeros(n,1);
    
    %Generate the Identity Matrix
    identityMatrix = eye(m,n);
    
    %Take the c value from the user.
    prompt = ['Enter the c value : '];
    c = input(prompt);
    
    %Initialize the reset vector to 1/n
       for j=1:n
           resetVector(j) = 1/n;
       end
       
    %Calculate Temporary Matrix
        tempstochasticMatrix = (1-c).*stochasticMatrix;
        y=identityMatrix - tempstochasticMatrix;
        k =det(y)
        temp = zeros(m,n);
        temp = inv(y);
        temp = c.*temp;
        steadyStateProbabilityVector = mtimes(temp,resetVector);
    
     %Enter the k value
        prompt = ['Enter the k value : '];
        k = input(prompt);
    
    %Compute the steady state probability vector
       % steadyStateProbabilityVector = mtimes(c.*(Inverse(identityMatrix - (1-c).*stochasticMatrix)),resetVector);
    
    [B,index]=sort(steadyStateProbabilityVector,1,'descend');
		[rows,cols]=size(steadyStateProbabilityVector);
		for i=1:k
            fprintf('Document=%d    PageRank=%d \n',index(i),B(i));
        end
end

