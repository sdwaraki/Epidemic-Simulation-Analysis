function [new_matrix] = resolveMatrix(old_matrix)
    new_matrix = zeros;
    [m,n] = size(old_matrix);
    for i = 1:m
        for j = 1:n-1
            new_matrix(i,j)=old_matrix(i,j);
        end
    end

end