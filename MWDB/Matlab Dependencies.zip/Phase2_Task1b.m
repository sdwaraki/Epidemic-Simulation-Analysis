function [similarity] = Phase2_Task1b( file1number, file2number )
%   Phase2Task1b : This function computes the DTW path length between the
%   two simulation files
%   @input: Simulation file 1, Simulation file2
%   @output: Similarity score

    % Read the CSV files
     file1 = ['C:\Users\Sumanth\workspace\Phase 1 Programs\InputData\' num2str(file1number) '.csv']; 
    file2 = ['C:\Users\Sumanth\workspace\Phase 1 Programs\InputData\' num2str(file2number) '.csv']; 
    
    %Read the relevant parts of the CSV files
    file1Matrix = csvread(file1,1,2);
    file2Matrix = csvread(file2,1,2);
 
    %State - Iteration Matrix
    file1Matrix = transpose(file1Matrix);
    file2Matrix = transpose(file2Matrix);
    
    %Obtaining sizes of the Matrices
    [m,n] = size(file1Matrix);
    [p,q] = size(file2Matrix);
    
    % For each state, compute the DTW distance between one state vector in 
    % one simulation file and the corresponding state in the 2nd simulation
    % file.
    % computeDTW function computes the DTW path and the cost of the
    % distance matrix.
    for i =1:m
        row1 = file1Matrix(i,:);
        row2 = file2Matrix(i,:);
        
        [row_row1,col_row1] = size(row1);
        [row_row2,col_row2] = size(row2);
        
        for j = 1:col_row1
            k=1;
            for k=1:col_row2
               matrix(j,k) =  (row1(row_row1,j)-row2(row_row2,k))^2;
            end
        end
        
        dtwvalue(i) = computeDtw(matrix);
        
    end
    
    [a,b] = size(dtwvalue);
    
    sum=0;
    
    %  To obtain the Similarity Scores.
    for i = 1:a
        dtwvalue(a,1)= sqrt(dtwvalue(a,1));
        sum = sum+dtwvalue(a,1);
    end
    
    avg = sum/a;
    
    similarity = 1/(1+avg);
    
end

