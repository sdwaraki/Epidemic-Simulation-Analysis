%Takes n by n similarity matrix and returns distance matrix
function distMatrix= calculateDistanceMatrix(similarityMatrix)

[m,n]=size(similarityMatrix);
distMatrix=zeros(m,n);
  for i =1:m          
      for j=1:n
        
        if(i==j)
          distMatrix(i,j)=0; 
        else
          distMatrix(i,j)=(1-similarityMatrix(i,j))/similarityMatrix(i,j);  
        
        end  
      end  
        
          
  end  
  
%disp(normMatrix);
% mappingErrorMatrix=abs(normMatrix-dist);
%disp(mappingErrorMatrix);


end