function [ ] = sortRetainingIndex3b(DP)

        [B,index]=sort(DP,1,'descend');
		[rows,cols]=size(DP);
		for i=1:cols
            fprintf('Topic=%d \n',full(i));
            for j=1:rows
                fprintf('Document=%d and Score=%d \n',full(index(j,i)),full(B(j,i)))
            end
		end
    
end