function [adjacencyMatrix] = generateAdjacencyMatrix(similarityMatrix)
% Takes in the similarityMatrix and generates the Adjacency Matrix
% Uses : getAdjacencyMatrixWithThreshold to generate the adjacency matrix
% and then plots the graph
    maximumSimilarity = max(similarityMatrix(:));
    minimumSimilarity = min(similarityMatrix(:));    
        
    prompt = [' Enter the threshold between '  num2str(minimumSimilarity) ' and ' num2str(maximumSimilarity) ':      '];
    threshold = input(prompt);
    adjacencyMatrix = getAdjacencyMatrixWithThreshold(threshold,similarityMatrix);
    
end

