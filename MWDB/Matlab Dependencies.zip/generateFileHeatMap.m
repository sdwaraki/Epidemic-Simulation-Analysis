function [] = generateFileHeatMap(fileName)
    M = importdata(fileName);
    m = transpose(M.data);
    figure;
    colormap('hot');
    imagesc(m);
    colorbar;
end