function [ dist ] = findEucledian(file1Matrix,file2Matrix )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
    [a,b] = size(file1Matrix);
    [m,n] = size(file2Matrix);
    
    
    for i = 1: a
        row1 = file1Matrix(i,:);
        row2 = file2Matrix(i,:);
        euc(i) = power(pdist2(row1,row2),2);
        
    end
    
    dist=0;
   
    for i= 1:a
       dist=dist+euc(i);
    end
     
    dist = sqrt(dist);
 end

