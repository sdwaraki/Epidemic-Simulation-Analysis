function [] =  queryTopSemantic(inputMatrix,p,k,r)
    %perform SVD over the input Matrix to get DT = DF*FF*TF
    [U,S,V] = svd(inputMatrix);
    %perform q * TF to project the query on to the Latent space
    qTF=mtimes(p,V);
    disp 'TF';
    
    disp(V);
    
    [m,n]=size(qTF);
    %Take only the top r semantics
    for i = r+1 :n
      for j = 1 :m
          qTF(j,i)=0;
      end
    end
    %Make it into a column vector
    qTF = transpose(qTF);
    disp 'qtf';
    disp(qTF);
    
    %project documents over to the Latent space
    temp = mtimes(U,S);
    [m,n]=size(temp);
    
    
    %Take only the top r semantics
    for i = r+1 :n
      for j = 1 :m
          temp(j,i)=0;
      end
    end
    
    disp 'temp'
    disp(temp);
    
    %Take the dot product of query on the latent space and DF over the
    %latent space
    result = mtimes(temp,qTF)
   
    disp 'result';
    disp(result);
    % use intermediate to sort the result and pick the top k results.
    intermediate = sort(result,'descend');
    
    
    [row_intermediate,col_intermediate] = size(intermediate);
       
       oldglobalcounter =1;
       globalcounter = 1;
       globalarray = [];
       
       for j = 1:row_intermediate
           index = find(result==intermediate(j));
           [row_index,col_index] = size(index);
           
           for c = 1:col_index
               if isempty(find(globalarray==index(c)))
                   globalarray(globalcounter) = index(c);
                   globalcounter = globalcounter + 1;
               end
           end
           
           for l = oldglobalcounter:globalcounter-1
                if k>0
                    disp(['File   ' num2str(globalarray(l)) '  Strength: ' num2str(result(globalarray(l)))]); 
                    k=k-1;
                end
           end
           
           oldglobalcounter = globalcounter;
       end 
          
end
