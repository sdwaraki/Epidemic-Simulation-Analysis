function [adjacencyMatrix] = Alternate_Phase3_Task3c(adjacencyMatrix)
    %This function generates the steady state probability vector according
    %to the paper given in the specification
    
    %Generate the stochastic matrix
    stochasticMatrix = computeNormalizedStochasticMatrix(adjacencyMatrix);
    [m,n] = size(stochasticMatrix);
    
    %Generate the reset Vector
    reset = zeros(n,1);
    
    %Take the c value from the user.
    prompt = ['Enter the c value : '];
    c = input(prompt);
    
    %Take the file numbers/ nodes that are the inital seeds that needs to
    %be personalized. 
    prompt = [' Enter the first simulation file'];
    firstSimulationFileNumber = input(prompt);
    prompt = ['Enter the second simulation file'];
    secondSimulationFileNumber = input(prompt);

     %Set the reset matrix based on the two file numbers given
    for i=1:n
        if(i==firstSimulationFileNumber || i==secondSimulationFileNumber)
            reset(i) = 0.5;
        end
    end
    
    computeAlternatePageRank(stochasticMatrix,reset,c);


end

