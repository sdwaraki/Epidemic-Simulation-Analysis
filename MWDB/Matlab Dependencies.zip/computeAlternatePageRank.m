function [] = computeAlternatePageRank(stochasticMatrix, reset, c)
    %This function calculates the PageRank in the way as proposed by the
    %paper in the project specification
    
    [m,n] = size(stochasticMatrix);
    
      
    %Initialize the revised Steady State Probability vector to check for
    %convergence
     revisedSteadyStateVector = zeros(n,1);
     
    %Initialize the steadyStateVector to reset Matrix
    steadyStateVector = reset;
    
        
    while(~isequal(round(steadyStateVector*1000)/1000000,round(revisedSteadyStateVector*1000)/1000000))
        firstTerm = mtimes(stochasticMatrix,steadyStateVector);
        firstTerm = (1-c).*firstTerm;
        secondTerm = c.*reset;
        steadyStateVector = revisedSteadyStateVector;
        revisedSteadyStateVector = firstTerm+secondTerm;
        iteration = iteration +1;
    end
    
    prompt = ['Enter the k value : '];
    k = input(prompt);
    
    [B,index]=sort(steadyStateVector,1,'descend');
		[rows,cols]=size(steadyStateVector);
		for i=1:k
            fprintf('Document=%d    PageRank=%d \n',index(i),B(i));
        end    
end
