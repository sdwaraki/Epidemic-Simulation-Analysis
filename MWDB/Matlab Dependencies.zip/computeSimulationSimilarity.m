function [ similarityMatrix ] = computeSimulationSimilarity(choice, r)
%computeSimulationSimilarity - Computes the Simulation - Simulation
%Similarity Matrix by taking into consideration the Eucledian Distance and
%the DTW distance
% returns the similarity matrix
%Takes in the directory path for the simulations and the choice - 1 for
%Eucledian Distance and 2 for DTW distance.
    
    disp(r);
    %dirPath = 'C:/Users/Sumanth/Desktop/Fall 2014/MWDB/sampledata_P1_F14/Epidemic Simulation Datasets/Input Simulation Files/'
    
    %dirPath = 'C:/Users/Sumanth/Desktop/Fall 2014/MWDB/sampledata_P1_F14/Data/'    
    
    dirPath = 'C:\Users\Sumanth\workspace\Phase 1 Programs\InputData\';
    similarityMatrix = zeros;
    %Find the count of the number of files in the directory
    n =length(dir([dirPath '\*.csv']));
    
    %Computing the Simulation Similarity Matrix
    for i = 1:n
        disp(i);
        for j= i+1:n
            if choice==1
                similarityMatrix(i,j) = Phase2_Task1a(i,j);
                similarityMatrix(j,i) = similarityMatrix(i,j);
            else
                similarityMatrix(i,j) = Phase2_Task1b(i,j);
                similarityMatrix(j,i) = similarityMatrix(i,j);
            end    
        end    
    end

    %Computing the diagonal Values of the Simulation Similarity Matrix
    for i =1:n
        similarityMatrix(i,i)=1;
    end

computeSVD(similarityMatrix,r);
    
end

