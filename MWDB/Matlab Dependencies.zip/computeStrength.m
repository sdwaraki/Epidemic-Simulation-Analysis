function computeStrength(dirPath,queryFilePath,choice,k)

    %similarity accounts for the similarity score between every the query
    %file and every epidemic word file. 
    similarity = zeros;
    n =length(dir([dirPath '\*.csv'])); % As the queryFile also is included in the same directory
    
    %qName = queryFilePath;
    numberOfResults = k;
    %Extract the query Matrix out of the given file
    qPath = [ queryFilePath '.csv'];
    qName=qPath;
    queryMatrix = csvread(qPath,0,3);
    queryMatrix = resolveMatrix(queryMatrix);
    
    %Extract the fileMatrix for each file and compute the similarity as per
    %the choice made.
    
    for i=1:n
        fileName = [dirPath num2str(i) '.csv'];
        fileMatrix = csvread(fileName,0,3);
        fileMatrix = resolveMatrix(fileMatrix);
        if choice == 1
            similarity(i) = getEucledian(fileMatrix,queryMatrix);
        else
            similarity(i) = getDTW(fileMatrix, queryMatrix);
        end
    end
    
    %Display the top k results as <File_Number, Strength>
    
    oldglobalcounter =1;
    globalcounter = 1;
    globalarray = zeros;
    temp = sort(similarity,'descend');
    [row_temp, col_temp] = size(temp);
    
    for j =1:col_temp
        index = find(similarity==temp(j));
        [~,col_index] = size(index);
        
        for c = 1:col_index
            if isempty(find(globalarray==index(c)))
                globalarray(globalcounter)=index(c);
                globalcounter = globalcounter+1;
            end
        end
        
        for l = oldglobalcounter:globalcounter-1
            if k>0
                disp(['File  ' num2str(globalarray(l)) '  Strength: ' num2str(similarity(globalarray(l)))]);
                k=k-1;
            end
        end
        
        oldglobalcounter = globalcounter;
    end
    
    %Display heatMaps for the query and the k most similar simulations
    
    generateHeatMaps(globalarray,numberOfResults);
    
    
    
end

