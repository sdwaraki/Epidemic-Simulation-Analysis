function [] = querySimulationSimilarityMatrix( objectFeatureMatrix, queryVector, simulationSimilarityMatrix, r, k )
%This function queries on the top r latent semantics and displays the top k
%results
%The tasks done in this function are:
%1. It brings the query from the feature space of the unique windows to the
%   feature space of the files. So query is expressed in terms of the files.
%2. It then computes the SVD on the Simulation similarity Matrix into U, S
%   and V matrix.
%3. Projects query in the latent space.
%4. Projects files in the latent space.
%5. Compute the query and files in the latent space. 

%   Query from the feature space of the unique windows to the
%   feature space of the files. So query is expressed in terms of the files.
queryInFileSpace = mtimes(queryVector,transpose(objectFeatureMatrix));

%   Compute SVD on the Simulation Similarity Matrix
[U,S,V] = svd(simulationSimilarityMatrix);

%   Project the query in the latent space

qTF = mtimes(queryInFileSpace,V);

[m,n]=size(qTF);

%   Take only the top r semantics.
    for i = r+1 :n
      for j = 1 :m
          qTF(j,i)=0;
      end
    end

%   Make it into a column vector
    qTF = transpose(qTF);    
    
%   project documents over to the Latent space or Projects files in the 
%   latent space.
    temp = mtimes(U,S);
    [m,n]=size(temp);
    
    
%   Take only the top r semantics
   for i = r+1 :n
      for j = 1 :m
          temp(j,i)=0;
      end
   end

%   Dot Product of query on the latent space and DF over the
%   latent space
    result = mtimes(temp,qTF);
    
    intermediate = sort(result,'descend');
    
%   Ordering the results in the array.

    [row_intermediate,col_intermediate] = size(intermediate);
       
       oldglobalcounter =1;
       globalcounter = 1;
       globalarray = [];
       
       for j = 1:row_intermediate
           index = find(result==intermediate(j));
           [row_index,col_index] = size(index);
           
           for c = 1:col_index
               if isempty(find(globalarray==index(c)))
                   globalarray(globalcounter) = index(c);
                   globalcounter = globalcounter + 1;
               end
           end
           
           for l = oldglobalcounter:globalcounter-1
                if k>0
                    disp(['File   ' num2str(globalarray(l)) '  Strength: ' num2str(result(globalarray(l)))]); 
                    k=k-1;
                end
           end
           
           oldglobalcounter = globalcounter;
       end 
       
end

