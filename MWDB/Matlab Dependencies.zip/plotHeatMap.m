function [] = plotHeatMap(inputMatrix, maxWindowStart, maxStateNumber, minWindowStart, minStateNumber, windowSize, maxOneHopNeighbors, minOneHopNeighbors)
    m = transpose(inputMatrix);
    colormap('hot');
    imagesc(m);
    colorbar;
    hold;
    [m,n] = size(maxOneHopNeighbors);
    [x,y] = size(minOneHopNeighbors);
    s = rectangle('Position',[MaxWindowStart,maxStateNumber,windowSize,1]);
    set(s,'edgecolor','g');
    hold;
    for i=1:n
        hold;
        plot(maxWindowStart,maxOneHopNeighbors(1,n),'x','MarkerSize',5);
    end
    hold;
    t = rectangle('Position',[minWindowStart,minStateNumber,windowSize,1]);
    set(t,'edgecolor','w');
    hold;
    for i=1:y
        hold;
        plot(minWindowStart,minOneHopNeighbors(1,i),'o','MarkerSize',5);
    end
end

