function [ output_args ] = Phase3_Task3c( adjacencyMatrix )
%Phase3_Task3c : This function computes the pagerank that is personalized
%taking two initial seeds from the user and increase the probability of
%reaching them in the restart vector.

%Generate the stochastic matrix
    stochasticMatrix = computeNormalizedStochasticMatrix(adjacencyMatrix);
    [m,n] = size(stochasticMatrix);
    
    %Generate the reset vector
    resetVector = zeros(m,n);
    
    %Take the c value from the user.
    prompt = ['Enter the c value : '];
    c = input(prompt);
    
    %Initialize the reset matrix
    reset = zeros(m,n);
    
    %Take the file numbers/ nodes that are the inital seeds that needs to
    %be personalized. 
    prompt = [' Enter the first simulation file'];
    firstSimulationFileNumber = input(prompt);
    prompt = ['Enter the second simulation file'];
    secondSimulationFileNumber = input(prompt);
    
    %Set the reset matrix based on the two file numbers given
    for i=1:n
        if(i==firstSimulationFileNumber || i==secondSimulationFileNumber)
            for j=1:n
                reset(i,j) = 0.5;
            end
        end
    end
    
    inputPageRankMatrix = zeros(m,n);
    
    %Initialize the inputPageRankMatrix based on the c value.
     for i=1:m
        for j=1:n
           % inputPageRankMatrix(i,j) = (1-c)*stochasticMatrix(i,j)+c*resetVector(i,j);
           inputPageRankMatrix(i,j) = (c)*stochasticMatrix(i,j)+(1-c)*resetVector(i,j);
        end
     end
     
    %Compute the PageRank
     computePageRank(inputPageRankMatrix);

end

