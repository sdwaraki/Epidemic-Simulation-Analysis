function [ queryVector ] = queryInFileSpace( queryFilePath )
    %To generate a query vector in terms of Simulation files.
    dirPath = 'C:/Users/Sumanth/workspace/Phase 1 Programs/InputData/'
    n =length(dir([dirPath '\*.csv']));
    
    %Reading the query file
    queryMatrix = csvread(queryFilePath,2,3);
        
    queryVector = zeros(1,n);
    
    for i =1:n
        filePath = [dirPath num2str(i) '.csv'];
        fileMatrix =csvread(filePath,2,3);
        queryVector(1,i)=findEucledian(queryMatrix,fileMatrix);
    end
    
    [a,b]=size(queryVector);
    queryVector(a,b+1)=0;
   
    
end

