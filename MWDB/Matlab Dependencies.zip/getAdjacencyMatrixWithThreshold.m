function [ adjacencyMatrix ] = getAdjacencyMatrixWithThreshold( threshold, similarityMatrix)
% getAdjacencyMatrixWithThreshold - Creates adjacency Matrix
% of the simulation files given the threshold for creati on of the edge
  [m,n] = size(similarityMatrix);
  %Create Adjacency Matrix of size m x n
  adjacencyMatrix = zeros(m,n);
  %edge only if similarity > threshold and no edge from one node to itself.
  for i =1:m
      for j =1:n
          if(similarityMatrix(i,j)>threshold)
              adjacencyMatrix(i,j)=1;
          end 
      end
  end
end

