function [ similarityMatrix ] = Task3f( choice )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

dirPath = 'C:\Users\Sumanth\workspace\Phase 1 Programs\InputData\';
    similarityMatrix = zeros;
    %Find the count of the number of files in the directory
    n =length(dir([dirPath '\*.csv']));
    
    %Computing the Simulation Similarity Matrix
    for i = 1:n
        disp(i);
        for j= i+1:n
            if choice==1
                similarityMatrix(i,j) = Phase2_Task1a(i,j);
                similarityMatrix(j,i) = similarityMatrix(i,j);
            else
                similarityMatrix(i,j) = Phase2_Task1b(i,j);
                similarityMatrix(j,i) = similarityMatrix(i,j);
            end    
        end    
    end

    %Computing the diagonal Values of the Simulation Similarity Matrix
    for i =1:n
        similarityMatrix(i,i)=1;
    end

end

