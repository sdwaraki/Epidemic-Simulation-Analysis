
function x= fastmap2(k,dist,pivot,x,col,n)
    
    if k<=0
        return;
    else
        col = col +1;
    end    
 %choose pivot objects i.e most distant objects in dist matrix
    Ob=randi([1,n]);
    max=dist(Ob,Ob);
    Oa=Ob;
    
    for i=Ob:Ob
        for j=1:n
         if max < dist(i,j)
             max=dist(i,j);
             Oa=j;
%          else
%              Oa=j;
         end 
         
        end
    end 
  
        max=0;
        
         for i=Oa:Oa
            for j=1:n
                if max < dist(i,j)
                    max=dist(i,j);
                    Ob=j;
%                 else
%                     Ob=j; 
                end
                
            end
         end    
  %-----------------------------------      
         disp(Oa);
         disp(Ob);
        

        %record id's of pivot object

        pivot(1,col)=Oa;
        pivot(2,col)=Ob;
        
        if dist(Oa,Ob)==0
           for i=1:n
               x(i,col)=0;
           end
        return
        end 
 
        %project objects
        
        for i=1:n
            x(i,col)= (power(dist(Oa,i),2)+power(dist(Oa,Ob),2)-power(dist(Ob,i),2))/(2*dist(Oa,Ob));

        end
             
         % compute distDash matrix
        for j=1:n
            for q=1:n
                term=(x(j,col)-x(q,col));
                distDash(j,q)=sqrt(power(dist(j,q),2)-power(term,2));
            end   
        end
    
  x=fastmap2(k-1,distDash,pivot,x,col,n);  
        
end
 


    




