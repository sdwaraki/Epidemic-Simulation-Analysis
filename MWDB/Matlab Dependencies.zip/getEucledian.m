function [similarity] = getEucledian(matrix1, matrix2)

    [m,n] = size(matrix1);
    
    for i = 1:m
        row1 = matrix1(i,:);
        row2 = matrix2(i,:);
        euc(i,1) = pdist2(row1,row2,'euclidean');
    end

    sum =0;
    [a,b] = size(euc);
    
    for i = 1:a
        sum = sum+euc(i,1);
    end
    
    avg = sum/a;
    similarity = 1/(1+avg);

end
