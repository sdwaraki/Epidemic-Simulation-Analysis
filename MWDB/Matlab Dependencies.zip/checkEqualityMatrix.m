function [ val ] = checkEqualityMatrix( m1, m2 )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    [a,b] = size(m1);
    [c,d] = size(m2);
    
    if(a~=c || b~=d)
        val=0;
        return;
    end
    
    for i = 1:a
        for j =1:b
            if( m1(i,j)~=m2(i,j))
                val=0;
                return;
            end
        end
    end
    
    val=1;
end

