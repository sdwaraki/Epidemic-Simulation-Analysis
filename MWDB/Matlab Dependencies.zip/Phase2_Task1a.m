function [similarity] = Phase2_Task1a(file1number, file2number)
    % Put the filePath as per the folder structure.
    file1 = ['C:\Users\Sumanth\Desktop\Fall 2014\MWDB\SampleData_P3_F14\SampleData_P3_F14\Data\' num2str(file1number) '.csv']; 
    file2 = ['C:\Users\Sumanth\Desktop\Fall 2014\MWDB\SampleData_P3_F14\SampleData_P3_F14\Data\' num2str(file2number) '.csv']; 
    
    %disp(file1number);
    %disp(file2number);
    file1Matrix = csvread(file1,1,2);
    file2Matrix = csvread(file2,1,2);
 
    file1Matrix = transpose(file1Matrix);
    file2Matrix = transpose(file2Matrix);
    
    [m,n] = size(file1Matrix);
    [p,q] = size(file2Matrix);
    
    for i = 1:m
       row1 = file1Matrix(i,:);
       row2 = file2Matrix(i,:);
       euc(i,1) = pdist2(row1,row2,'euclidean');
    end
    
    sum =0;
    
    [a,b] = size(euc);
    
    for i = 1:a
        sum = sum+euc(a,1);
    end
    
    avg = sum/a;
    
    similarity = 1/(1+avg);
    
end

