function generateHeatMaps( globalarray,k )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

    dirPath = 'C:/Users/Sumanth/workspace/Phase 1 Programs/InputData/';
    
    for i =1:k
        filePath = [dirPath num2str(globalarray(i)) '.csv'];
        matrix = csvread(filePath,1,2);
        matrix = transpose(matrix);
        figure;
        colormap('hot');
        imagesc(matrix);
    end
    
    qPath = 'C:/Users/Sumanth/workspace/Phase 1 Programs/InputQuery/query.csv';
    queryMatrix = csvread(qPath,1,2);
    queryMatrix = transpose(queryMatrix);
    figure;
    imagesc(queryMatrix);

end

