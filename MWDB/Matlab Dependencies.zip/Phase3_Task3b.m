function [  ] = Phase3_Task3b( adjacencyMatrix )
% This function calculates the pagerank of different nodes given an
% adjacency matrix to identify the important nodes in the graph. 
% 
    %Generate the stochastic matrix
    stochasticMatrix = computeNormalizedStochasticMatrix(adjacencyMatrix);
    [m,n] = size(stochasticMatrix);
    
    %Generate the reset vector
    resetVector = zeros(m,n);
    
    %Take the c value from the user.
    prompt = ['Enter the c value : '];
    c = input(prompt);
    
    %Initialize the reset vector to 1/n
    for i=1:m
        for j=1:n
            resetVector(i,j) = 1/n;
        end
    end
    
    inputPageRankMatrix = zeros(m,n);
    
    %Initialize the inputPageRankMatrix based on the c value.
     for i=1:m
        for j=1:n
           % inputPageRankMatrix(i,j) = (1-c)*stochasticMatrix(i,j)+c*resetVector(i,j);
           inputPageRankMatrix(i,j) = (c)*stochasticMatrix(i,j)+(1-c)*resetVector(i,j);
        end
     end
     
    %Compute the PageRank
     computePageRank(inputPageRankMatrix);

end

