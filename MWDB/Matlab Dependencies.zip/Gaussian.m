function [ y ] = Gaussian(r)

    xl=0;
    M(r)=0;
    y(r)=0;
    syms x
    fun = (1/(0.25*sqrt(2 * pi))) * exp(((-1/2)*(x.^2))/((0.25 *0.25)));
    
    for i=1:r 
        xu=xl+(1/r);
        M(i)= int(fun,x,xl,xu);
        D = int(fun,x,0,1);
        y(i)=M(i)/D;
        xl=xu;
    end


end

